package org.firstinspires.ftc.teamcode.virtualvision;

import com.qualcomm.robotcore.robocol.TelemetryMessage;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.openftc.easyopencv.OpenCvPipeline;

public class powerplayConePipeline extends OpenCvPipeline {

    private final Mat RedConeMat      = new Mat();
    private final Mat BlueConeMat     = new Mat();

    public enum ConeColor {
        RED,
        BLUE
    }
    private ConeColor coneColor = ConeColor.RED;

    private int hueMin          = 0;
    private int hueMax          = 180;
    private int saturationMin   = 0;
    private int saturationMax   = 255;
    private int valueMin        = 0;
    private int valueMax        = 255;

    private final Scalar HSVMin = new Scalar(hueMin, saturationMin, valueMin);
    private final Scalar HSVMax = new Scalar(hueMax, saturationMax, valueMax);

    Telemetry telemetry;

    public powerplayConePipeline(ConeColor coneColor, Telemetry telemetry, int hueMin, int hueMax, int saturationMin, int saturationMax, int valueMin, int valueMax) {
        this.coneColor      = coneColor;
        this.telemetry      = telemetry;

        this.hueMin         = hueMin;
        this.hueMax         = hueMax;
        this.saturationMin  = saturationMin;
        this.saturationMax  = saturationMax;
        this.valueMin       = valueMin;
        this.valueMax       = valueMax;
    }

    @Override
    public Mat processFrame(Mat InputMat) {

        if(InputMat.empty()) {
            return InputMat;
        }

        String HueTelemetry = "Hue Range: " + HSVMin.val[0] + " - " + HSVMax.val[0];
        String SaturationTelemetry = "Saturation Range: " + HSVMin.val[1] + " - " + HSVMax.val[1];
        String ValueTelemetry = "Value Range: " + HSVMin.val[2] + " - " + HSVMax.val[2];

        InputMat.convertTo(InputMat, CvType.CV_8U);

        PrintTelemetry(HueTelemetry, SaturationTelemetry, ValueTelemetry);

        final Mat BlurredMat    = new Mat();
        BlurredMat.convertTo(BlurredMat, CvType.CV_8U);

//      Clear the image
        Imgproc.blur(InputMat, BlurredMat, new Size(7, 7));

        final Mat HSVMat        = new Mat();
        HSVMat.convertTo(HSVMat, CvType.CV_8U);

//      Convert to HSV
        Imgproc.cvtColor(BlurredMat, HSVMat, Imgproc.COLOR_RGB2HSV);

        final Mat MaskMat       = new Mat();
        MaskMat.convertTo(MaskMat, CvType.CV_8U);

//      Filter everything not in HSV range
        Core.inRange(HSVMat, HSVMin, HSVMax, MaskMat);

        final Mat BitwiseMat    = new Mat();
        BitwiseMat.convertTo(BitwiseMat, CvType.CV_8U);

//      Keep only detected parts of image
        Core.bitwise_and(MaskMat, MaskMat, BitwiseMat, HSVMat);

//      Convert back to RGB
        Imgproc.cvtColor(BitwiseMat, InputMat, Imgproc.COLOR_HSV2RGB);

//      Release all unreturned Mats
        HSVMat.release();
        MaskMat.release();
        BitwiseMat.release();

//      PLEASE WORK!!!!!!!
        return InputMat;

        /*if (coneColor == ConeColor.BLUE) {

            return BlueConeMat;
        }

        else if (coneColor == ConeColor.RED) {

            return RedConeMat;
        }

        return InputMat;*/
    }

    private void PrintTelemetry(String HueTelemetry, String SaturationTelemetry, String ValueTelemetry) {
        telemetry.addLine(HueTelemetry);
        telemetry.addLine(SaturationTelemetry);
        telemetry.addLine(ValueTelemetry);
    }
}
