package org.firstinspires.ftc.teamcode.virtualvision;

import com.acmerobotics.dashboard.config.Config;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvWebcam;

@Config
@Autonomous
public class pipelineTest extends LinearOpMode {

    powerplayConePipeline pipeline;
    int cameraMonitorViewId;
    OpenCvWebcam camera;


    @Override
    public void runOpMode() throws InterruptedException {

        int hueMin          = 0;
        int hueMax          = 180;
        int saturationMin   = 0;
        int saturationMax   = 255;
        int valueMin        = 0;
        int valueMax        = 255;

        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        camera = OpenCvCameraFactory.getInstance().createWebcam(hardwareMap.get(WebcamName.class, "Webcam"));
        pipeline = new powerplayConePipeline(powerplayConePipeline.ConeColor.BLUE, telemetry, hueMin, hueMax, saturationMin, saturationMax, valueMin, valueMax);

        camera.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener()
        {
            @Override
            public void onOpened()
            {
                camera.setPipeline(pipeline);
                camera.startStreaming(800,448, OpenCvCameraRotation.UPRIGHT);
            }

            @Override
            public void onError(int errorCode)
            {

            }
        });

        waitForStart();

        while(opModeIsActive() && !isStopRequested()) {

            sleep(50);
        }

    }
}
