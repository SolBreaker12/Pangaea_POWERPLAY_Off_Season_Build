package org.firstinspires.ftc.teamcode.roadrunner.trajectorysequence;


public class EmptySequenceException extends RuntimeException { }
